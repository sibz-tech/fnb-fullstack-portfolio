
def area(length, width):
    # Function to calculate area of rectangle
    return length * width

def perimeter(length, width):
    # Function to calculate perimeter of rectangle
    return 2 * (length + width)
# Finally, print the area and perimeter of the rectangle.