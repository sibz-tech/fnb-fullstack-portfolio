# Numeric Data
# No quotes needed for numeric data

num = 3 # num = 3.14 # Float- No quotes needed

print(3) # Prints 3
print(type(num)) # Prints value of num variable

num2 = 3.14

print(type(num2)) # Prints value of num2 variable

# In Python you don't have to declare data types it automatically declares it for you