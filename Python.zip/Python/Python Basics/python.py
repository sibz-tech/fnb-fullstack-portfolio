# Python Basics: A language overview

# Operators with Strings & Numeric Data Types
# Numeric Data Types: int, float, complex
# Variables 
# Loops
# Control Statements
