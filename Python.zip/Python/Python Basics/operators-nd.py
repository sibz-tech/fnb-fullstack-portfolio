#Operators

# Addition (+)
# Subtraction (-)
# Multiplication (*)
# Division (/)  # Float division
# Floor Division (//) # Integer division        
# Modulus (%) # Remainder after division
# Exponentiation (**)

x = 10
y = 2

print(x + y) # Addition
print(x - y) # Subtraction
print(x * y) # Multiplication
print(x / y) # Division
print(x % y) # Modulus
print(5 % 2) # Remainder
print(x ** y) # Exponentiation

# Assignment Operators
# =, +=, -=, *=, /=, %=, //=, **=

x = 10
x += 2
x -= 2
x *= 2

print(x)
